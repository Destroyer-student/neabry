var config = {} 


// your telegram API credentials
// please go to https://my.telegram.org to create your API credentials
config.telegramApiId = 10900450;
config.telegramApiHash = 'ff7faa6d48c95101ad660987c105e239';


// server settings
config.hostname = '127.0.0.1';
config.port = 3000;


module.exports = config;